package MapReduce;

//import Factory.DataFrameFactory;

public class MainMapReduce {

	public static void main(String[] args) {
		
		//we have been trying to make the map reduce pattern but we did not get any solution
		
		
		//DataFrameMapReduce data = null;
		//long size = data.MapReduce(null, null);
		//System.out.println("Valor: "+size);

	}

}
