package MapReduce;

//imports
import java.util.ArrayList;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Stream;

import Factory.DataFrameFactory;

/**
 * 
 * @author Alfred Manuel, Marc Sala
 *
 */
public class DataFrameMapReduce {
	
	//variables
	private final List<DataFrameFactory> dataFrame;
	
	/**
	 * Constructor
	 */
	public DataFrameMapReduce() {
		dataFrame = new ArrayList<>();
	}
	
	/**
	 * function to add a dataframe to the list
	 * @param data dataframe to be added
	 */
	public void addDataFrame(DataFrameFactory data) {
		dataFrame.add(data);
	}
	
	/**
	 * function to implement the map reduce logic
	 * @param <T> generic type
	 * @param map map function
	 * @param reduce reduce logic
	 * @return result of the map reduce
	 */
	public <T> T MapReduce(Function<DataFrameFactory,T> map, BinaryOperator<T> reduce){
        Stream<DataFrameFactory> datafr = dataFrame.parallelStream();
        return datafr.map(map).reduce(reduce).get();
    }

}
