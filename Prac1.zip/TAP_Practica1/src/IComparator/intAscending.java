package IComparator;

//imports
import java.util.Comparator;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * class for sorting the elemets ascendingly 
 *
 */
public class intAscending implements Comparator<Object> {

	/**
	 * function compare, to return if the values is bigger, lower or the same
	 */
	@Override
	public int compare(Object o1, Object o2) {
		
		String str1 = o1.toString();
		String str2 = o2.toString();
		
		int compare = str1.compareTo(str2);
		
		if(compare < 0) {
			return -1;
		}
		else if(compare > 0) {
			return 1;
		}
		else {
			return 0;
		}
		
	}

}
