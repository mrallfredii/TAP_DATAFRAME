package composite;

//imports
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;

import Visitor.Visitor;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	interface of composite pattern
 */
public interface Component {
	
	/**
	 * find a position in the dataframe and return the object 
	 * @param row number of row in the dataframe
	 * @param name name of the label
	 * @return object in that position
	 */
	public Object at(int row, String name);
	
	/**
	 * find a position in the dataframe and return the object 
	 * @param row number of row in the dataframe
	 * @param columns number if column in the dataframe
	 * @return object in that position
	 */
	public Object iat(int row, int columns);
	
	/**
	 * getter of the number of columns of the dataframe
	 * @return number of columns
	 */
	public Object columns();
	
	/**
	 * getter number of rows/elements in the dataframe
	 * @return number of rows 
	 */
	public Object size();
	
	/**
	 * Find in a concrete column the objects that bypass the comparator and return them
	 * @param column name of the label 
	 * @param comparator condition of the search
	 * @return array of objects that pass the comparator
	 */
	public List<Object> sort(Object column, Comparator<Object> comparator);
	
	/**
	 * Return a dataframe of the elements that bypass the condition
	 * @param pred condition
	 * @param label column
	 * @return dataframe
	 */
	public Object[][] query(Predicate<Object> pred, String label);
	
	/**
	 * void that accept a visitor
	 * @param v visitor to accept
	 */
	public void accept(Visitor v);
}
