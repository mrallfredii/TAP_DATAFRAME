package composite;

//imports
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import Factory.DataFrameFactory;
import Visitor.Visitor;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 *
 *class that implements component 
 */
public class Directory implements Component {
	
	//variables
	private String name;
	private List<Component> children;
	static int index;
	
	/**
	 * constructor of the class directory
	 * @param name of the directory
	 */
	public Directory(String name) {
		this.name = name;
		children = new LinkedList<Component>();
	}
	
	/**
	 * function getter of the directory name
	 */
	public Object getName() {
		return name;
	}
	
	/**
	 * function to add a child in the directory, can be another directory or a file
	 * @param child
	 */
	public void addChild(Component child) {
		children.add(child);
	}
	
	/**
	 * function to remove a child of the directory
	 * @param child
	 */
	public void removeChild(Component child) {
		children.remove(child);
	}

	/**
	 * implementation of the method at in a directory
	 */
	@Override
	public Object at(int row, String name) {
		
		 index = row;
		 Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				index = index - (int)aux.size();
				if(index <= 0) {
					return aux.at(index, name);
				}
			}
			else{
				ob = aux.at(index, name);
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implementation of the method iat in a directory
	 */
	@Override
	public Object iat(int row, int columns) {

		 index = row;
		 Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				index = index - (int)aux.size();
				if(index <= 0) {
					return aux.iat(index, columns);
				}
			}
			else{
				ob = aux.iat(index, columns);
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implementation of the method columns in a directory
	 */
	@Override
	public Object columns() {

		Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
					return aux.columns();
				
			}
			else{
				ob = aux.columns();
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implmentation of the method size in a directory
	 */
	@Override
	public Object size() {

		int totalSize = 0;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
					totalSize += (int)aux.size();
				
			}
			else{
				totalSize += (int)aux.size();
			}
		}
		
		return totalSize;
	}

	/**
	 * implmentation of the method sort in a directory
	 */
	@Override
	public List<Object> sort(Object column, Comparator<Object> comparator) {

		List<Object> list = new ArrayList<>();
		List<Object> listTotal = new ArrayList<>();
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				list = aux.sort(column, comparator);
				for(Object ob : list) {
					listTotal.add(ob);
				}
			}
			else {
				list = aux.sort(column, comparator);
				for(Object ob : list) {
					listTotal.add(ob);
				}
			}
		}
		listTotal = listTotal.stream().sorted(comparator).collect(Collectors.toList());
		
		return listTotal;
	}
	
	/**
	 * implmentation of the method query in a directory
	 */
	@Override
	public Object[][] query(Predicate<Object> pred, String label) {
				
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				aux.query(pred, label);
			}
			else {
				aux.query(pred, label);
			}
			System.out.println("\n");
		}
		
		return null;
	}

	/**
	 * getter of the list of children
	 * @return list of children
	 */
	public List<Component> getChildren() {
		return children;
	}

	/**
	 * function to accept a visitor in a directory
	 */
	@Override
	public void accept(Visitor v) {
		v.visit(this);
	}
	

}
