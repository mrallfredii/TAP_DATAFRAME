package composite;

//imports
import java.util.function.Predicate;
import Factory.DataFrameFactory;
import Factory.FileFactory;
import IComparator.intAscending;
import IComparator.intDescending;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main class of the composite pattern
 */
public class MainComposite {
	
	/**
	 * main of the composite pattern 
	 * @param args
	 */
	public static void main(String[] args) {
		
	FileFactory file = new FileFactory();	
		
	//setup for execution 
	Directory root = new Directory("root");
	DataFrameFactory f1 = file.getFile("prueba1.txt");
	DataFrameFactory f2 = file.getFile("cities.json");
	DataFrameFactory f3 = file.getFile("cities.csv");;
	root.addChild(f1);
	root.addChild(f2);
	
	Directory user = new Directory("user");
	user.addChild(f3);
	root.addChild(user);
	
	//at
	System.out.println("\n--> Function at\n");
	System.out.println("[Directory]");
	System.out.println(root.at(1, "LatM"));
	System.out.println("[File]");
	System.out.println(f2.at(0, "LatD"));
	
	//iat
	System.out.println("\n--> Function iat\n");
	System.out.println("[Directory]");
	System.out.println(root.iat(1, 2));
	System.out.println("[File]");
	System.out.println(f2.iat(0, 1));
	
	//columns
	System.out.println("\n--> Function columns\n");
	System.out.println("[File]");
	System.out.println(f2.columns());
	System.out.println("[Directory]");
	System.out.println(root.columns());
	
	//size
	System.out.println("\n--> Function size\n");
	System.out.println("[File]");
	System.out.println(f2.size());
	System.out.println("[Directory]");
	System.out.println(root.size());
	
	//sort
	System.out.println("\n--> Function sort\n");
	System.out.println("[Ascending sort Directory]");
	System.out.println(root.sort("LatD", new intAscending()));
	System.out.println("[Descending sort Directory]");
	System.out.println(user.sort("LatD", new intDescending()));
	
	//query
	System.out.println("\n--> Function query isBigger Directory\n");
	Predicate<Object> isBigger = str -> Integer.parseInt((String) str) > 119;
	root.query(isBigger, "LonD");
	}
}
