package Observer;
/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that extends Observer class
 */
public class QueryObserver extends Observer {
	
	/**
	 * this method register a new operation in the list of the observer
	 */
	@Override
	public void addOperation(String operation) {
		super.listLogOperation.add(operation);
	}
	
	/**
	 * toString of the list of operations registered in QueryObserver list
	 */
	@Override
	public String toString() {
		return "QueryObserver [listLogOperation=" + listLogOperation + "]";
	}
}
