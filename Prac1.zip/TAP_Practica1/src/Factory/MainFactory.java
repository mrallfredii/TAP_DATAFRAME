package Factory;

//imports
import java.util.function.Predicate;
import IComparator.intAscending;
import IComparator.intDescending;
import Visitor.AvarageVisitor;
import Visitor.MaximumVisitor;
import Visitor.MinimumVisitor;
import Visitor.SumVisitor;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main of Factory and Observer pattern
 *
 */
public class MainFactory {
	
	/**
	 * main of the factory pattern 
	 * @param args
	 */
	public static void main(String[] args) {
		
		//variables
		FileFactory factory = new FileFactory();
		//dataframe for txt file
		DataFrameFactory file1 = factory.getFile("prueba1.txt");
		//dataframe for csv file
		DataFrameFactory file2 = factory.getFile("cities.csv");
		//dataframe for json file
		DataFrameFactory file3 = factory.getFile("cities.json");
		
		//Print txt dataframe
		System.out.println("[Dataframe of txt]");
		file1.printDataFrame();
		//Print csvdataframe
		System.out.println("\n[Dataframe of csv]");
		file2.printDataFrame();
		//Print json dataframe
		System.out.println("\n[Dataframe of json]");
		file3.printDataFrame();
				
		//at
		System.out.println("\n--> Function at");
		System.out.println("[DATAFRAME OF TXT]");
		System.out.println(file1.at(1, "LonD"));
		System.out.println("[DATAFRAME OF CSV]");
		System.out.println(file2.at(100, "LonD"));
		System.out.println("[DATAFRAME OF JSON]");
		System.out.println(file3.at(2, "LonD"));
		
		//iat
		System.out.println("\n--> Function iat");
		System.out.println("[DATAFRAME OF TXT]");
		System.out.println(file1.iat(1, 4));
		System.out.println("[DATAFRAME OF CSV]");
		System.out.println(file2.iat(3, 3));
		System.out.println("[DATAFRAME OF JSON]");
		System.out.println(file3.iat(1, 2));
		
		//columns
		System.out.println("\n--> Function columns");
		System.out.println("[DATAFRAME OF TXT]");
		System.out.println(file1.columns());				
		System.out.println("[DATAFRAME OF CSV]");
		System.out.println(file2.columns());				
		System.out.println("[DATAFRAME OF JSON]");
		System.out.println(file3.columns());	
		
		//size
		System.out.println("\n--> Function size");
		System.out.println("[DATAFRAME OF TXT]");
		System.out.println(file1.size());
		System.out.println("[DATAFRAME OF CSV]");
		System.out.println(file2.size());
		System.out.println("[DATAFRAME OF JSON]");
		System.out.println(file3.size());
		
		//sort
		System.out.println("\n--> Function sort");
		System.out.println("[DATAFRAME OF TXT ASCENDING]");
		System.out.println(file1.sort("LatD", new intAscending()));
		System.out.println("[DATAFRAME OF TXT DESCENDING]");
		System.out.println(file1.sort("LatD", new intDescending()));
		System.out.println("[DATAFRAME OF CSV ASCENDING]");
		System.out.println(file2.sort("LatD", new intAscending()));
		System.out.println("[DATAFRAME OF CSV DESCENDING]");
		System.out.println(file2.sort("LatD", new intDescending()));
		System.out.println("[DATAFRAME OF JSON ASCENDING]");
		System.out.println(file3.sort("City", new intAscending()));
		System.out.println("[DATAFRAME OF JSON DESCENDING]");
		System.out.println(file3.sort("City", new intDescending()));
						
		//query	
		System.out.println("\n--> Function query");
		Predicate<Object> isBigger = str -> Integer.parseInt((String) str) > 119;
		Predicate<Object> isLower = str -> Integer.parseInt((String) str) < 119;
		Predicate<Object> isEqual = str -> str.equals("Yaon");
		
		System.out.println("\n--> Function query isBigger txt");
		file1.query(isBigger, "LonD");
		
		System.out.println("\n--> Function query isLower csv");
		file2.query(isLower, "LonD");
		
		System.out.println("\n--> Function query isEqual json");
		file3.query(isEqual, "City");
		
		//observers
		System.out.println("\n--> observer of txt");
		System.out.println(file1.getObservers());
		System.out.println("\n--> observer of csv");
		System.out.println(file2.getObservers());
		System.out.println("\n--> observer of json");
		System.out.println(file3.getObservers());
					
		//iterator
		System.out.println("\n--> iterator of csv");
		int cont = 1;
		while(file2.iterator().hasNext()) {
			System.out.println("Posicion [" + cont + "]" + " " + file2.iterator().next());
			cont++;
		}
		
		//visitors
		AvarageVisitor visitAvg = new AvarageVisitor("LonD");
		SumVisitor visitSum = new SumVisitor("LonD");
		MaximumVisitor visitMax = new MaximumVisitor("LonD");
		MinimumVisitor visitMin = new MinimumVisitor("LonD");
				
		file2.accept(visitAvg);
		file2.accept(visitMin);
		file2.accept(visitMax);
		file2.accept(visitSum);
				
		System.out.println("\n--> avarage visitor [factory]");
		System.out.println(visitAvg.getAverage());
		System.out.println("\n--> sum visitor [factory]");
		System.out.println(visitSum.getSum());
		System.out.println("\n--> maximum visitor [factory]");
		System.out.println(visitMax.getMaximum());
		System.out.println("\n--> minimum visitor [factory]");
		System.out.println(visitMin.getMinimum());
	}	
}
