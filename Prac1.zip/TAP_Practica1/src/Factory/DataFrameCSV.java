package Factory;

//imports
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Class for csv files
 *
 */
public class DataFrameCSV extends DataFrameFactory{

	/**
	 * Constructor
	 * @param fileName name of the file
	 */
	public DataFrameCSV(String fileName) {
		super(fileName);
	}
	
	/**
	 * Function setFile, to the values that contain the csv file and make the dataframe
	 * @return dataframe of csv
	 */
	public Object [][] setFile(String fileName) {
		
		//get the file
		File file = new File(fileName);
		columnsRows(fileName);
		//we know the dimension of the dataframe
		Object[][] dataframeAux= new Object[super.getRows()][super.getColumns()];
		
		try {
			Scanner input = new Scanner(file);
			String data = input.nextLine();
			String[] values= {};
			
			int index=1;
			if(data !=null) {	
				values = data.split(",");
				
				for(int i=0; i<values.length;i++) {
					dataframeAux[0][1+i]=values[0+i].trim();
				}
			}
			while(input.hasNext()) {
				 data = input.nextLine();
				 values = data.split(",");
				 dataframeAux[index][0]=index-1;
				 for(int i=1; i<values.length+1;i++) {
						dataframeAux[index][0+i]=values[i-1].trim();
					}
				 index++;
				
			}
			input.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		super.setDataframe(dataframeAux);
		
		 return dataframeAux;
	}
	
	/**
	 * Function columnsRows, to know the amount of rows and columns of the file
	 * @param fileName name of the file
	 */
	private void columnsRows(String fileName) {
		int rows=0;
		File file = new File(fileName);
		Scanner input;
		try {
			input = new Scanner(file);
			String data = input.nextLine();
			//csv columns are splited by ,
			String[] values=data.split(",");
			super.setColumns(values.length+1);
			
			//while have, we will know the rows
			while(input.hasNext()) {
				rows++;
				input.nextLine();
			}
			super.setRows(rows+1);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}


}
