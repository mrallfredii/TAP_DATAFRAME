package Factory;

//imports
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Class for txt files
 *
 */
public class DataFrameTXT extends DataFrameFactory{
	
	private Scanner in;

	/**
	 * Constructor
	 * @param fileName name of the file
	 */
	public DataFrameTXT(String fileName) {
		super(fileName);
	}

	/**
	 * Function setFile, to the values that contain the txt file and make the dataframe
	 * @return dataframe of csv
	 */
	public Object [][] setFile(String fileName) {
		
		File file = new File(fileName);
		
		//the user will decide the spliter depending on the txt file
		in = new Scanner(System.in);
		System.out.println("What kind of determinator have your txt: ");
		String determinator = in.next();
		
		//we wanna know the dimensions of the dataframe
		columnsRows(fileName, determinator);
		Object[][] dataframeAux= new Object[super.getRows()][super.getColumns()];
		
		try {
			Scanner input = new Scanner(file);
			String data = input.nextLine();
			String[] values= {};
		
			int index=1;
			if(data !=null) {	
				values = data.split(determinator);
				
				for(int i=0; i<values.length;i++) {
					dataframeAux[0][1+i]=values[0+i].trim();
				}
			}
			while(input.hasNext()) {
				 data = input.nextLine();
				 values = data.split(determinator);
				 dataframeAux[index][0]=index-1;
				 for(int i=1; i<values.length+1;i++) {
						dataframeAux[index][0+i]=values[i-1].trim();
					}
				 index++;
				
			}
			input.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		super.setDataframe(dataframeAux);
		
		 return dataframeAux;
	}
	
	/**
	 * Function columnsRows, to know the amount of rows and columns of the file
	 * @param fileName name of the file
	 * @param determinator the spliter used
	 */
	private void columnsRows(String fileName, String determinator) {
		
		int rows=0;
		File file = new File(fileName);
		Scanner input;
		
		try {
			input = new Scanner(file);
			String data = input.nextLine();
			String[] values=data.split(determinator);
			super.setColumns(values.length+1);
			
			while(input.hasNext()) {
				rows++;
				input.nextLine();
				
			}
			super.setRows(rows+1);
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
