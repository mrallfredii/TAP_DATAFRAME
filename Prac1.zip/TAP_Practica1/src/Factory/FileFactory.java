package Factory;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Class FileFactory to choose what dataframe create
 *
 */
public class FileFactory{

	/**
	 * function that depending on the extension of the file will instance a txt or csv or json dataframe
	 * @param fileName name of the file
	 * @return new dataframe
	 */
	public DataFrameFactory getFile(String fileName) {
		
		//Get the file extension with regex
		String aux = fileName.split("\\.")[1];
		
		if(aux.equals("json")) {
			return new DataFrameJSON(fileName);
		}
		else if(aux.equals("csv")) {
			return new DataFrameCSV(fileName);
		}
		else if(aux.equals("txt")) {
			return new DataFrameTXT(fileName);
		}
		else return null;
	}
}