package Proxy;

//imports
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

import Factory.DataFrameFactory;
import Factory.FileFactory;
import Visitor.Visitor;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that implements DataFrame Interface
 */
public class ProxyDataFrame implements DataFrame {
	
	//variables
	private FileFactory file = new FileFactory();
	private String fileName;
	private DataFrameFactory dataFrameReal = null;

	/**
	 * constructor of the class
	 * @param fileName
	 */
	public ProxyDataFrame(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * implementations of the functions at of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Object at(int row, String name) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.at(row, name);
	}

	/**
	 * implementations of the functions iat of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Object iat(int row, int columns) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.iat(row, columns);
	}
	
	/**
	 * implementations of the functions columns of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Object columns() {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.columns();
	}

	/**
	 * implementations of the functions size of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Object size() {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.size();
	}
	
	/**
	 * implementations of the functions sort of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public List<Object> sort(Object column, Comparator<Object> comparator) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.sort(column, comparator);
	}

	/**
	 * implementations of the functions query of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Object[][] query(Predicate<Object> pred, String label) {
		
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.query(pred, label);
	}
	
	/**
	 * implementations of the functions iterator of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public Iterator<Object> iterator() {
		
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.iterator();
	}
	
	/**
	 * implementations of the functions listColumns of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public List<Object> listColumns(String label) {
		
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.listColumns(label);
	}
	
	/**
	 * implementations of the functions accept of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */
	@Override
	public void accept(Visitor v) {
		
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		dataFrameReal.accept(v);
	}

}
