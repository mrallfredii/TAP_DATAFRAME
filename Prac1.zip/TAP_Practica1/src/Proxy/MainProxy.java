package Proxy;

//import
import IComparator.intAscending;
import IComparator.intDescending;
import Visitor.AvarageVisitor;
import Visitor.MaximumVisitor;
import Visitor.MinimumVisitor;
import Visitor.SumVisitor;
import java.util.function.Predicate;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main class of the dynamic Proxy
 */
public class MainProxy {

	/**
	 * main of the dynamic proxy 
	 * @param args
	 */
	public static void main(String[] args) {
		
		DataFrame data = new ProxyDataFrame("prueba1.txt");
		
		//at
		System.out.println("\n--> Function at [proxy]");
		System.out.println(data.at(0, "LonD"));
		
		//iat
		System.out.println("\n--> Function iat [proxy]");
		System.out.println(data.iat(0, 0));
		
		//columns
		System.out.println("\n--> Function columns [proxy]");
		System.out.println(data.columns());
		
		//size
		System.out.println("\n--> Function size [proxy]");
		System.out.println(data.size());
		
		//sort
		System.out.println("\n--> Function sort [proxy]");
		System.out.println("[SORT DESCENDING]");
		System.out.println(data.sort("LonD", new intDescending()));
		System.out.println("[SORT ASSCENDING]");
		System.out.println(data.sort("LonD", new intAscending()));
		
		//query
		System.out.println("\n--> Function query [proxy]");
		Predicate<Object> isBigger = str -> Integer.parseInt((String) str) > 119;
		System.out.println("\n--> Function query isBigger txt");
		data.query(isBigger, "LonD");
		
		//iterator
		System.out.println("\n--> iterator [proxy]");
		int cont = 1;
		while(data.iterator().hasNext()) {
			System.out.println("Posicion [" + cont + "]" + " " + data.iterator().next());
			cont++;
		}
		
		//visitors
		AvarageVisitor visitAvg = new AvarageVisitor("LonD");
		SumVisitor visitSum = new SumVisitor("LonD");
		MaximumVisitor visitMax = new MaximumVisitor("LonD");
		MinimumVisitor visitMin = new MinimumVisitor("LonD");
		
		data.accept(visitAvg);
		data.accept(visitMin);
		data.accept(visitMax);
		data.accept(visitSum);
		
		System.out.println("\n--> avarage visitor [proxy]");
		System.out.println(visitAvg.getAverage());
		System.out.println("\n--> sum visitor [proxy]");
		System.out.println(visitSum.getSum());
		System.out.println("\n--> maximum visitor [proxy]");
		System.out.println(visitMax.getMaximum());
		System.out.println("\n--> minimum visitor [proxy]");
		System.out.println(visitMin.getMinimum());
	}

}
