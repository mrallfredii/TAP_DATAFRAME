package Proxy;

//imports
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;

import Visitor.Visitor;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	interface of dataframe for dynamic proxy
 */
public interface DataFrame {
	
	/**
	 * declaration of the headers of the proxy functions 
	 */
	public Object at(int row, String name);
	public Object iat(int row, int columns);
	public Object columns();
	public Object size();
	public List<Object> sort(Object column, Comparator<Object> comparator);
	public Object[][] query(Predicate<Object> pred, String label);
	public Iterator<Object> iterator();
	public List<Object> listColumns(String label);
	public void accept(Visitor v);
}
