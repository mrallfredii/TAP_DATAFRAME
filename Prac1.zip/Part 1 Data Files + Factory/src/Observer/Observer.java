package Observer;

import java.util.LinkedList;
import java.util.List;
/**
 * 
 * @author Marc Sala, Alfred Manuel
 *	abstract class observer
 */
public abstract class Observer {
	/**
	 * variables
	 */
	List<String> listLogOperation = new LinkedList<>();
	
	/**
	 * getter of the list of logged operations
	 * @return
	 */
	public List<String> getListLogOperation() {
		return listLogOperation;
	}
	
	/**
	 * abstract void to add a new operation in the list
	 * @param operation
	 */
	public abstract void addOperation(String operation);

	/**
	 * toString of the list of logged operations 
	 */
	@Override
	public String toString() {
		return "Observer [listLogOperation=" + listLogOperation + "]";
	}
	
}
