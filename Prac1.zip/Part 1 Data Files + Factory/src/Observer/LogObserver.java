package Observer;
/**
 * 
 * @author Marc Sala, Alfred Manuel
 * class extends observer
 */
public class LogObserver extends Observer {
	
	/**
	 * this method register a new operation in the list of the observer
	 */
	@Override
	public void addOperation(String operation) {
		super.listLogOperation.add(operation);	
	}

	/**
	 * toString of the list of operations registered in LogObserver list
	 */
	@Override
	public String toString() {
		return "LogObserver [listLogOperation=" + listLogOperation + "]";
	}	
	
	
}
