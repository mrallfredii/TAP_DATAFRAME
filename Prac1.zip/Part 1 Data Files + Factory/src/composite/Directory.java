package composite;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import Factory.DataFrameFactory;
import Visitor.Visitor;
/**
 * 
 * @author Marc Sala, Alfred Manuel
 *
 *class that implements component 
 */
public class Directory implements Component {
	/**
	 * variables
	 */
	private String name;
	private List<Component> children;
	static int index;
	
	/**
	 * constructor of the class directory
	 * @param name
	 */
	public Directory(String name) {
		this.name = name;
		children = new LinkedList<Component>();
	}
	
	/**
	 * xxxxxxxxxxxxxxxxx
	 */
	public Object getName() {
		return name;
	}
	
	/**
	 * function to add a child in the directory, can be another directory or a file
	 * @param child
	 */
	public void addChild(Component child) {
		children.add(child);
	}
	/**
	 * function to remove a child of the directory
	 * @param child
	 */
	public void removeChild(Component child) {
		children.remove(child);
	}

	/**
	 * implementation of the method at in a directory
	 */
	@Override
	public Object at(int row, String name) {

		System.out.print("at function\n[" + this.name + "] DIRECTORY: \n");
		 index = row;
		 Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				index = index - (int)aux.size();
				if(index <= 0) {
					return aux.at(index, name);
				}
			}
			else{
				ob = aux.at(index, name);
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implementation of the method iat in a directory
	 */
	@Override
	public Object iat(int row, int columns) {

		System.out.print("iat function\n[" + this.name + "] DIRECTORY: \n");
		 index = row;
		 Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
				index = index - (int)aux.size();
				if(index <= 0) {
					return aux.iat(index, columns);
				}
			}
			else{
				ob = aux.iat(index, columns);
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implementation of the method columns in a directory
	 */
	@Override
	public Object columns() {

		System.out.print("columns function\n[" + this.name + "] DIRECTORY: \n");
		Object ob;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
					return aux.columns();
				
			}
			else{
				ob = aux.columns();
				if(ob != null) {
					return ob;
				}
			}
		}
		
		return null;
	}

	/**
	 * implmentation of the method size in a directory
	 */
	@Override
	public Object size() {

		System.out.print("size function\n[" + this.name + "] DIRECTORY: \n");
		int totalSize = 0;
		
		for(Component aux : children) {
			if(aux.getClass().equals(DataFrameFactory.class)) {
					totalSize += (int)aux.size();
				
			}
			else{
				totalSize += (int)aux.size();
			}
		}
		
		return totalSize;
	}

	/**
	 * implmentation of the method sort in a directory
	 */
	@Override
	public List<Object> sort(Object column, Comparator<Object> comparator) {

		System.out.println("sort function\n[" + this.name + "] DIRECTORY: \n");
		return null;
	}

	//**********************************************************FER JAVADOC DE QUERY QUAN ESTIGUI FET************************************
	// @Override
	// public Object[][] query() {
	// return null;
	// }

	/**
	 * getter of the list of children
	 * @return
	 */
	public List<Component> getChildren() {
		return children;
	}

	/**
	 * function to accept a visitor in a directory
	 */
	@Override
	public void accept(Visitor v) {
		v.visit(this);
	}

	

}
