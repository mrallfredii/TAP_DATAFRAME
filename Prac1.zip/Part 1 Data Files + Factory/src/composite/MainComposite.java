package composite;

import Factory.DataFrameFactory;
import Factory.FileFactory;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main class of the composite pattern
 */
public class MainComposite {
	/**
	 * main of the composite pattern 
	 * @param args
	 */
	public static void main(String[] args) {
		
	Directory root = new Directory("root");
	FileFactory file = new FileFactory();
	DataFrameFactory f1 = file.getFile("prueba1.txt");
	DataFrameFactory f2 = file.getFile("cities.json");
	DataFrameFactory f3 = file.getFile("cities.csv");
	root.addChild(f1);
	root.addChild(f2);
	
	Directory user = new Directory("user");
	user.addChild(f3);
	user.addChild(f2);
	root.addChild(user);
	root.addChild(f1);
	
	System.out.println(root.at(1, "LatM"));
	//System.out.println(f2.at(0, "LatD"));
	
	//System.out.println(root.iat(1, 2));
	//System.out.println(f2.iat(0, 1));
	
	//System.out.println(f2.columns());
	//System.out.println(root.columns());
	
	//System.out.println(f2.size());
	//System.out.println(root.size());


	}
}
