package Visitor;

import java.util.List;

import Factory.DataFrameFactory;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that extends visitor class
 */
public class AvarageVisitor extends Visitor{

	/**
	 * variables
	 */
	private double average;
	private double sumTotal;
	private int index;
	private String labelName;

	/**
	 * constructor of the class
	 * @param labelName
	 */
	public AvarageVisitor(String labelName){
		this.labelName=labelName;
		this.average=0;
		this.sumTotal=0;
		this.index=0;
	}

	/**
	 * visit method of the class, that calculate the average of
	 * the files or directory
	 */
	@Override
	public void visit(DataFrameFactory file) {
		
		List<Object> list = file.listColumns(labelName);

		for(Object element : list){
			sumTotal += Double.parseDouble((String)element);
			index++;
		}
		average=sumTotal/index;
	}

	/**
	 * getter of average variable
	 * @return average
	 */
	public double getAverage(){
		return average;
	}
	
}
