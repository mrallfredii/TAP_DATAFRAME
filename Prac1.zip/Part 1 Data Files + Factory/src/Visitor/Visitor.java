package Visitor;

import Factory.DataFrameFactory;
import composite.Component;
import composite.Directory;
/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	abstract class
 */
public abstract class Visitor {
	
	/**
	 * abstract void of function visit for files
	 * @param file 
	 */
	public abstract void visit(DataFrameFactory file);
	
	/**
	 * void visit to accept all the children in a directory
	 * @param dir direcotry
	 */
	public void visit(Directory dir) {
		
		for(Component element : dir.getChildren()) {
			element.accept(this);
		}
	}

}
