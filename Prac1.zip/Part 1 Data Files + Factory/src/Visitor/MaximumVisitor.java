package Visitor;

import java.util.List;

import Factory.DataFrameFactory;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that extends visitor class
 */
public class MaximumVisitor extends Visitor{

	/**
	 * variables
	 */
	private int maximum;
	private String labelName;
	private int cont;

	/**
	 * constructor of the class
	 * @param labelName
	 */
	public MaximumVisitor(String labelName){
		this.labelName=labelName;
		this.maximum=0;
		this.cont=0;
	}

	/**
	 * visit method of the class, that save the maximum value 
	 * of the files or directory
	 */
	@Override
	public void visit(DataFrameFactory file) {

		List<Object> list = file.listColumns(labelName);
		
		for(Object element : list){
			if(cont == 0){
				maximum = Integer.parseInt((String)element);
				cont++;
			}
			if(Integer.parseInt((String)element) > maximum){
				maximum = Integer.parseInt((String)element);
			}
		}
	}

	/**
	 * getter of maximum variable
	 * @return maximum
	 */
	public int getMaximum(){
		return maximum;
	}

}
