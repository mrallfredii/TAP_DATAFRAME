package Visitor;

import java.util.List;

import Factory.DataFrameFactory;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that extends visitor class
 */
public class SumVisitor extends Visitor{
	
	/**
	 * variables
	 */
	private int sum;
	private String labelName;
	
	/**
	 * constructor of the class
	 * @param labelName
	 */
	public SumVisitor(String labelName) {
		this.labelName = labelName;
		this.sum = 0;
	}

	/**
	 * visit method of the class, that calculate the total summatory of the 
	 * values of the files or directory
	 */
	@Override
	public void visit(DataFrameFactory file) {
		
		List<Object> list = file.listColumns(labelName);
		
		for(Object element : list) {
			sum += Integer.parseInt((String)element);
		}
		
	}

	/**
	 * getter of sum variable
	 * @return sum
	 */
	public int getSum() {
		return sum;
	}
	
}
