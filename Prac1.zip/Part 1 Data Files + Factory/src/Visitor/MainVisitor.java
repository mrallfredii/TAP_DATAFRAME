package Visitor;

import Factory.DataFrameFactory;
import Factory.FileFactory;
import composite.Directory;


/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main class of the visitor pattern
 */
public class MainVisitor {

	/**
	 * main of the visitor pattern 
	 * @param args
	 */
	public static void main(String[] args) {
		
		FileFactory file = new FileFactory();
		
		Directory root = new Directory("root");
		DataFrameFactory f1 = file.getFile("prueba1.txt");
		root.addChild(f1);
		//root.addChild(f2);
		
		MinimumVisitor min = new MinimumVisitor("LatD");
		root.accept(min);
		System.out.println(min.getMinimum());
		
		MaximumVisitor max = new MaximumVisitor("LatM");
		root.accept(max);
		System.out.println(max.getMaximum());
		
		AvarageVisitor avg = new AvarageVisitor("LatM");
		root.accept(avg);
		System.out.println(avg.getAverage());
		
		SumVisitor sum = new SumVisitor("LatM");
		root.accept(sum);
		System.out.println(sum.getSum());
		

	}

}
