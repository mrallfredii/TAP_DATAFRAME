package Factory;

//imports
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Class for json files
 *
 */
public class DataFrameJSON extends DataFrameFactory{
	
	/**
	 * Constructor
	 * @param fileName name of the file
	 */
	public DataFrameJSON(String fileName) {
		super(fileName);
	}
	
	/**
	 * Function setFile, to the values that contain the json file and make the dataframe
	 * @return dataframe of csv
	 */
	public Object [][] setFile(String fileName) {
		
		//we need a parser, thaks to the referenced libraries
		JSONParser parser = new JSONParser(); 
		
		Object[][] dataframeAux = null;
		
		try {
			
			//convert the values of json to objects
			Object obj = parser.parse(new FileReader(fileName));
			
			//then to array
			JSONArray jsonArray = new JSONArray(obj.toString());
			
			//the columns will be always the same
			dataframeAux= new Object[jsonArray.length()+1][11];
			super.setColumns(11);
			super.setRows(jsonArray.length() + 1);
			
			//to get the label columns
			org.json.JSONObject jsonObject = jsonArray.getJSONObject(0);
			
			//to know the dimension of the columns
			Iterator<?> keys = jsonObject.keys();
			
			int j=1;
			
			while(keys.hasNext()) {
				
				dataframeAux[0][j]=keys.next();
				j++;
				
			}
			
			Object ob = null;
			String aux = "";
			int cont = 0;
			
			for(int i = 0; i < jsonArray.length(); i++) {
				
				cont = 0;
											
				dataframeAux[i+1][0]=i;
				
				jsonObject = jsonArray.getJSONObject(i);
				keys = jsonObject.keys();
				
				
				while(keys.hasNext()) {
					
					ob = jsonObject.get((String) keys.next());
					aux = ob.toString();
					dataframeAux[i+1][cont+1]=aux;
					cont++;
				}	
				
			 }
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		 return dataframeAux;
		
	}

}
