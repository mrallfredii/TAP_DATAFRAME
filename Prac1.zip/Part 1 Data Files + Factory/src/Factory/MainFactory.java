package Factory;

//imports
import java.util.Comparator;
import java.util.Scanner;
import java.util.function.Predicate;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main of Factory and Observer pattern
 *
 */
public class MainFactory {
	
	//dataframe for txt file
	static DataFrameFactory file1;
	//dataframe for csv file
	static DataFrameFactory file2;
	//dataframe for json file
	static DataFrameFactory file3;
	
	public static void main(String[] args) {
		
		//variables
		FileFactory factory = new FileFactory();
		int cont = 1;
		
		/**
		 * Comparator for sort function
		 */
		Comparator<Object> com = new Comparator<Object>() {

			@Override
			public int compare(Object o1, Object o2) {
				return 0;
			}
			
		};
		
		//Menu that the user will choose what file work with
		try (Scanner input = new Scanner(System.in)) {
			System.out.println("[WELCOME TO THE FACTORY PART]\n");
			System.out.println("\t1 --> txt");
			System.out.println("\t2 --> csv");
			System.out.println("\t3 --> json");
			System.out.println("\t0 --> exit");
			System.out.println("\n[Choose the number to work with that file]: ");
			int in = input.nextInt();
			
			while(in != 0) {
				
				switch(in) {
				
					case 1:
						//txt file
						System.out.println("\n[DATAFRAME OF TXT]\n");
						//instance of txt
						file1 = factory.getFile("prueba1.txt");
						//print the dataframe
						file1.printDataFrame();
						//sort function
						System.out.println(file1.sort("LatM", com));
						//txt get the observer info
						file1.getObservers();
						break;
					
					case 2:
						//csv file
						System.out.println("\n[DATAFRAME OF CSV]\n");
						//instance of csv
						file2 = factory.getFile("cities.csv");
						//print the dataframe
						file2.printDataFrame();
						//function at
						System.out.println("\n\n\n"+file2.at(8, "LonD"));
						//function iat
						System.out.println("\n\n\n"+file2.iat(3, 3));
						//function columns
						System.out.println(file2.columns());
						//function size
						System.out.println(file2.size());
						//csv get the observer info
						System.out.println(file2.getObservers());
						//query function
						query(file2);
						break;
						
					case 3:
						//json file
						System.out.println("\n[DATAFRAME OF JSON]\n");
						//instance of json
						file3 = factory.getFile("cities.json");
						//print the dataframe
						file3.printDataFrame();
						//iterator function
						cont = 1;
						while(file3.iterator().hasNext()) {
							System.out.println("Posicion [" + cont + "]" + " " + file3.iterator().next());
							cont++;
						}
						break;
						
					default:
						//user put a invalid number
						System.out.println("\nOh no, bad number! Hold on\n");
						System.out.println("\t1 --> txt");
						System.out.println("\t2 --> csv");
						System.out.println("\t3 --> json");
						System.out.println("\t0 --> exit");
				}
				//until the user puts 0
				System.out.println("\n[WELCOME TO THE FACTORY PART AGAIN!]\n");
				System.out.println("\t1 --> txt");
				System.out.println("\t2 --> csv");
				System.out.println("\t3 --> json");
				System.out.println("\t0 --> exit");
				System.out.println("\n\n[Choose the number to work with that file]: ");
				in = input.nextInt();
			}
		}	
	}

	/**
	 * Function query that will call the function query of the dataframe
	 * @param file extension of the file
	 */
	private static void query(DataFrameFactory file) {
		
		System.out.println("\nFuntion query:");
		System.out.println("\nConditions to choose");
		System.out.println("\t1 --> isEqual");
		System.out.println("\t2 --> isBigger");
		System.out.println("\t3 --> isLower");
		System.out.println("\t0 --> exit");
		System.out.println("\nChoose the number depending on what condition you want: ");
		
		try (Scanner input = new Scanner(System.in)) {
			int in2 = input .nextInt();
			
			while(in2 != 0) {
				switch(in2) {
				
					case 1:
						System.out.println("\nPut the string of the word you wanna match: ");
						String in3 = input.nextLine();
						//Predicate isEqual, compare the input with the name of the column
						Predicate<Object> isEqual = String -> String.equals(in3);
						file.query(isEqual, "Lon");
						break;
						
					case 2:
						System.out.println("\nPut the number of which will only appear the bigger ones: ");
						int in4 = input.nextInt();
						//Predicate isBigger, show the values bigger than the input one
						Predicate<Object> isBigger = String -> Integer.parseInt((java.lang.String) String) > in4;
						file.query(isBigger, "Lon");
						break;
						
					case 3:
						System.out.println("\nPut the number of which will only appear the littles ones: ");
						int in5 = input.nextInt();
						//Predicate isLower, show the values lower than the input one
						Predicate<Object> isLower = String -> Integer.parseInt((java.lang.String) String) < in5;
						file.query(isLower, "Lon");
						break;
						
					default:
						//user put a invalid number
						System.out.println("\nOh no, bad number! Hold on\n");
						System.out.println("\t1 --> isEqual");
						System.out.println("\t2 --> isBigger");
						System.out.println("\t3 --> isLower");
				}
			}
		}
	}
}
