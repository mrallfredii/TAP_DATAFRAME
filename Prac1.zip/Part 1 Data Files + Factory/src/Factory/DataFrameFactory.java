package Factory;

//imports
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import Observer.LogObserver;
import Observer.Observer;
import Observer.QueryObserver;
import Proxy.DataFrame;
import Visitor.Visitor;
import composite.Component;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Class for the operation that contains the dataframe
 *
 */
public abstract class DataFrameFactory implements Iterable<Object>, DataFrame, Component {

	//variables
	private Object [][] dataframe;
	private int rows;
	private int columns;
	static private int contRow = 1;
	static private int contCol = 1;
	List<Observer> observers = new LinkedList<>();
	String operationName;
	Observer observerl = new LogObserver();
	Observer observerq = new QueryObserver();
	
	/**
	 * Constructor
	 * @param fileName name of the file
	 */
	public DataFrameFactory(String fileName) {
		this.rows = 0;
		this.columns = 0;
		this.dataframe = setFile(fileName);
		attach(this.observerl);
		attach(this.observerq);
	}
	
	////////OBSERVER////////
	/**
	 * Function to add the observer
	 * @param observer log or query observers
	 */
	public void attach(Observer observer) {
		observers.add(observer);
	}
	
	/**
	 * Function to notify the observer
	 * @param operationName name of the operation
	 */
	public void notifyObserver(String operationName) {
		
		for(Observer observer : observers) {
			//we don't wanna enter the query as xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
			if(!operationName.equals("query")) {
				if(observer.getClass().equals(LogObserver.class)) {
					observer.addOperation(operationName);
				}
			}else {
				observer.addOperation(operationName);
			}
		}
	}
	
	/**
	 * Function to get all the observers
	 * @return observers
	 */
	public List<Observer> getObservers() {
		System.out.print("\nList of Observers\n");
		return observers;
	}
	////////END OF OBSERVER////////

	////////SETTERS AND GETTERS////////
	public Object[][] getDataframe() {
		return dataframe;
	}

	public void setDataframe(Object[][] dataframe) {
		this.dataframe = dataframe;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	public int getColumns() {
		return columns;
	}

	public void setColumns(int columns) {
		this.columns = columns;
	}
	////////END OF SETTERS AND GETTERS////////

	/**
	 * Function to decompress the selected file to make the dataframe
	 * @param fileName name of the file
	 * @param dataframe
	 */
	public abstract Object[][] setFile(String fileName);
	
	/**
	 * Function to print the dataframe
	 */
	public void printDataFrame() {
		for(int i=0; i<rows;i++) {
			for(int e=0;e<columns;e++) {
				System.out.print(dataframe[i][e]+"\t");
			}
			System.out.println();
		}
	}
	
	/**
	 * Function at, search with item row and column label meet
	 * @param row what to search
	 * @param name what column to search
	 * @return object of the value found
	 */
	public Object at(int row, String name) {
			
		System.out.println("\n--> Function at\n");
		
		//we must observe this function
		operationName = "at";
		notifyObserver(operationName);
		
		//variable to know if the value is in the matrix
		int aux = -1;
		String content ="";
	
		if(row <= rows-1) {	
			
			for(int i=1; i<columns; i++) {
				content=String.valueOf(dataframe[0][i]);
				
				if(content.equals(name)) {
					aux = i;
				}
			}
		}
				
		if(aux != -1) {
			return dataframe[row+1][aux];
		}
		else return null;		
	}
		
	/**
	 * Function iat, search with integer row and integer column meet
	 */
	public Object iat(int row, int column) {
		
		System.out.println("\n--> Function iat\n");
		
		//we must observe this function
		operationName = "iat";
		notifyObserver(operationName);
			
		if((row <= rows-1) && (column <= columns-1)) {
			return dataframe[row+1][column+1];
		}
		else return null;	
		}
		
	/**
	 * Function columns, search the number of labels
	 */
	public Object columns() {	
		System.out.println("\n--> Function columns\n");
		//we must observe this function
		operationName = "columns";
		notifyObserver(operationName);
		return columns-1;
	}
		
	/**
	 * Function size, search the number of rows
	 */
	public Object size() {	
		System.out.println("\n--> Function size\n");
		//we must observe this function
		operationName = "size";
		notifyObserver(operationName);
		return rows-1;
	}
		
	/**
	 * Function sort, xxxxxxxxxxxxxxxxxxxxxxxxxxx
	 * @param column
	 * @param comp
	 * @return
	 */
	public List<Object> sort(Object column, Comparator<Object> comp) {
		
		System.out.println("\n--> Function sort\n");
		
		operationName = "sort";
		notifyObserver(operationName);
			
		ArrayList<Object> li = (ArrayList<Object>) listColumns((String) column);
		
		List<Object> sortedList = li.stream().sorted(comp).collect(Collectors.toList());
		
		return sortedList;			
	}
	
	/**
	 * Function listColumns, xxxxxxxxxxxxxxxxxxxxxxxxxx
	 * @param label
	 * @return
	 */
	public List<Object> listColumns(String label){
		
		List<Object> li = new ArrayList<Object>();
		String content;
		int aux = -1;
		
		for(int j=0; j<columns-1; j++) {
            content=String.valueOf(dataframe[0][j+1]);
            if(content.equals(label)) {
                aux = j+1;
            }
        }

		for(int i=0; i<rows-1; i++) {
			li.add(dataframe[i+1][aux]);
        }
		
		return li;
	}

	/**
	 * Function query, xxxxxxxxxxxxxxxxxxxxxxxxxx
	 * @param pred
	 * @param label
	 * @return
	 */
	public Object[][] query(Predicate<Object> pred, String label) {
		
		System.out.println("\n--> Function query\n");
			
		operationName = "query";
		notifyObserver(operationName);
		
		int aux = getColumnsLabel(label);
		List<Object> list = new ArrayList<>();
			
		for(int i=0;i < rows-1;i++) {		
			list.add(dataframe[i+1][aux]);
		}
		//list.forEach(System.out::println);
		//list.stream().filter(pred).forEach(x -> method);
			
			return null;
		}
		
	/**
	 * Function getColumnsLabel, xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
	 * @param label
	 * @return
	 */
	private int getColumnsLabel(Object label) {
			
		for(int i=0;i < columns-1;i++) {
			if(dataframe[0][i+1].equals(label)) {
				return i+1;
			}
		}
		return 0;
	}
		
	/**
	 * Function iterator, to loop the whole values by order in the dataframe
	 */
	@Override
	public Iterator<Object> iterator() {
					
		Iterator<Object> i= new Iterator<Object>() {
				 
			/**
			 * Function hasNext, to know if the are more values in the dataframe
			 * @return boolean if it has value or not
			 */
	           @Override
	           public boolean hasNext() {
	               
	               if(contRow < rows) {
	            	   return true;
	               }
	               else {
	            	   contRow = 1;
	            	   return false;
	               } 
	           }
	               
	           /**
	            * Function resetIndexes, to reset the columns and increment the rows, to go through all the values
	            */
	           private void resetIndexes() {
	        	   if(contCol == dataframe[contRow].length) {
	        		   contCol = 1;
	        		   contRow++;
	        	   }
	           }
	            
	           /**
	            * Function next, to get value by value of the dataframe
	            * @return the actual value
	            */
	           @Override
	           public Object next() {
	            
	        	//no values
	            if(hasNext() == false) {
	            	throw new NoSuchElementException();
	            }
	            	
	            while(contRow < dataframe.length) {
	            	
	            	while(contCol < dataframe[contRow].length) {
	            		
	            		if(dataframe[contRow][contCol] != null) {
	            			Object ob = dataframe[contRow][contCol];
	            			contCol++;
	            			resetIndexes();
	            			return ob;
	            		}
	            		else {
	            			contCol++;
	            			resetIndexes();
	            		}
	            	}
	            	contRow++;
	            } 			
	            return null;           		            	
	           }
		};
			
		return i;
	}
	
	@Override
	public void accept(Visitor v) {
		v.visit(this);
	}
	
}