package IComparator;

import Factory.FileFactory;

import Factory.DataFrameFactory;

public class MainComparator {

	public static void main(String[] args) {
		
		FileFactory file=new FileFactory();
		DataFrameFactory ex1= file.getFile("cities.csv");
		System.out.println(ex1.sort("Ascending" + "Cit", new intAscending()));
		//System.out.println(ex1.sort("Descending" + "Cit", new intDescending()));

	}

}
