package Proxy;

import java.util.Comparator;
import java.util.List;

import Factory.DataFrameFactory;
import Factory.FileFactory;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	class that implements DataFrame Interface
 */
public class ProxyDataFrame implements DataFrame {
	
	/**
	 * variables
	 */
	private FileFactory file = new FileFactory();
	private String fileName;
	private DataFrameFactory dataFrameReal = null;

	/**
	 * constructor of the class
	 * @param fileName
	 */
	public ProxyDataFrame(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * implementations of the functions of the DataframeFactory(RealClass)
	 * for ProxyDataFrame(ProxyClass)
	 */

	@Override
	public Object at(int row, String name) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.at(row, name);
	}

	@Override
	public Object iat(int row, int columns) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.iat(row, columns);
	}

	@Override
	public Object columns() {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.columns();
	}

	@Override
	public Object size() {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.size();
	}

	@Override
	public List<Object> sort(Object column, Comparator<Object> comparator) {
		if(dataFrameReal == null) {
			dataFrameReal = file.getFile(fileName);
		}
		return dataFrameReal.sort(column, comparator);
	}
	

}
