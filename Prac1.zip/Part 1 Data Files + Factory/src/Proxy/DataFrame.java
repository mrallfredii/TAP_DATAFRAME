package Proxy;

import java.util.Comparator;
import java.util.List;

/**
 * 
 * @authors Marc Sala, Alfred Manuel
 *
 *	interface of dataframe for dynamic proxy
 */
public interface DataFrame {
	
	/**
	 * declaration of the headers of the proxy functions 
	 */
	public Object at(int row, String name);
	public Object iat(int row, int columns);
	public Object columns();
	public Object size();
	public List<Object> sort(Object column, Comparator<Object> comparator);
	//public Object[][] query();
}
