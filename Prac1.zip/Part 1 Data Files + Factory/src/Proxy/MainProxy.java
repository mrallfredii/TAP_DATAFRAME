package Proxy;

/**
 * 
 * @author Marc Sala, Alfred Manuel
 * Main class of the dynamic Proxy
 */
public class MainProxy {

	/**
	 * main of the dynamic proxy 
	 * @param args
	 */
	public static void main(String[] args) {
		
		DataFrame data = new ProxyDataFrame("prueba1.txt");
		System.out.println(data.at(0, "LonD"));
		System.out.println(data.iat(0, 0));
		System.out.println(data.columns());

	}

}
